package com.dtos;

import lombok.Data;

@Data
public class DogDto {
	
	private Long Id;
	private String name;
	private String race;
	
}
